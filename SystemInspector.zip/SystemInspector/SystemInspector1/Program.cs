﻿using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Versioning;
using System.Text;
using Microsoft.Win32;
using SystemLibrary;

namespace SystemInspector
{
    internal static class Program
    {
        const int FlagProcesses = 1 << 0;
        const int FlagCommands = 1 << 1;
        const int FlagNetwork = 1 << 2;
        const int FlagReport = 1 << 3;
        const int AllFlags = FlagProcesses | FlagCommands | FlagNetwork | FlagReport;

        static readonly string[] FlagNames =
        {
            "получение информации о процессах",
            "выполнение системных команд",
            "проверка сети",
            "сохранение отчёта"
        };

        const string RegistryPath = @"Software\SystemInspector";
        static readonly string SettingsFile = Path.Combine(AppContext.BaseDirectory, "settings.txt");

        static int flags = AllFlags;
        static int launchCount = 0;

        static string computerName = null;
        static string userName = null;
        static int processCount = -1;
        static string[] topNames = new string[0];
        static int[] topPids = new int[0];
        static long[] topMemory = new long[0];
        static string[] pingResults = null;
        static int evenCount = -1;
        static string arrayResult = null;
        static string memoryResult = null;

        const string NotDone = "не выполнялось";

        static async Task Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            try { Encoding.RegisterProvider(CodePagesEncodingProvider.Instance); }
            catch { }

            LoadSettings();
            launchCount++;
            SaveSettings();
            Console.WriteLine($"запуск программы №{launchCount}");

            bool running = true;
            while (running)
            {
                PrintMenu();
                string choice = Console.ReadLine();
                if (choice == null) break;
                Console.WriteLine();

                try
                {
                    switch (choice.Trim())
                    {
                        case "1": ShowComputerInfo(); break;
                        case "2": AnalyzeProcesses(); break;
                        case "3": await CheckNetworkAsync(); break;
                        case "4": AnalyzeArrayInThreads(); break;
                        case "5": CheckMemory(); break;
                        case "6": ConfigureSettings(); break;
                        case "7": await RunFullDiagnosticsAsync(); break;
                        case "8": SaveReport(); break;
                        case "0": running = false; break;
                        default:
                            Console.WriteLine("некорректный ввод. введите число от 0 до 8.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"непредвиденная ошибка: {ex.Message}");
                }

                if (running)
                {
                    Console.WriteLine("\nнажмите enter, чтобы вернуться в меню...");
                    if (Console.ReadLine() == null) break;
                }
            }

            Console.WriteLine("работа программы завершена.");
        }

        static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("========== system inspector ==========");
            Console.WriteLine();
            Console.WriteLine("1. информация о компьютере");
            Console.WriteLine("2. анализ процессов");
            Console.WriteLine("3. проверка сети");
            Console.WriteLine("4. анализ массива в двух потоках");
            Console.WriteLine("5. проверка памяти");
            Console.WriteLine("6. настройки диагностики");
            Console.WriteLine("7. полная диагностика");
            Console.WriteLine("8. сохранить отчёт");
            Console.WriteLine("0. выход");
            Console.Write("\nвыберите пункт: ");
        }

        static void PrintHeader(string title)
        {
            Console.WriteLine();
            Console.WriteLine($"----- {title} -----");
        }

        static bool IsFlagSet(int mask)
        {
            return (flags & mask) != 0;
        }

        static void PrintDisabled(int bit)
        {
            Console.WriteLine($"функция «{FlagNames[bit]}» отключена в настройках (бит {bit}). включите её в пункте 6.");
        }

        static void ShowComputerInfo()
        {
            if (!IsFlagSet(FlagCommands)) { PrintDisabled(1); return; }

            PrintHeader("информация о компьютере");

            var host = RunCommand("hostname", "");
            if (host.ExitCode == 0 && host.Output.Length > 0)
            {
                computerName = FirstLine(host.Output);
            }
            else
            {
                Console.WriteLine($"ошибка команды hostname: {host.Output}");
                computerName = Environment.MachineName + " (получено через environment)";
            }
            Console.WriteLine($"имя компьютера: {computerName}");

            var who = RunCommand("whoami", "");
            if (who.ExitCode == 0 && who.Output.Length > 0)
            {
                userName = FirstLine(who.Output);
            }
            else
            {
                Console.WriteLine($"ошибка команды whoami: {who.Output}");
                userName = Environment.UserName + " (получено через environment)";
            }
            Console.WriteLine($"пользователь:   {userName}");

            string cmd, args;
            if (OperatingSystem.IsWindows()) { cmd = "ipconfig"; args = ""; }
            else if (OperatingSystem.IsLinux()) { cmd = "ip"; args = "addr"; }
            else { cmd = "ifconfig"; args = ""; }

            Console.WriteLine($"\nсетевые интерфейсы ({cmd} {args}):");
            var net = RunCommand(cmd, args);
            if (net.ExitCode == 0)
                Console.WriteLine(net.Output);
            else
                Console.WriteLine($"ошибка выполнения команды (код {net.ExitCode}): {net.Output}");
        }

        static string FirstLine(string text)
        {
            string[] lines = text.Split('\n');
            return lines[0].Trim();
        }

        static void AnalyzeProcesses()
        {
            if (!IsFlagSet(FlagProcesses)) { PrintDisabled(0); return; }

            PrintHeader("анализ процессов");

            Process[] all;
            try
            {
                all = Process.GetProcesses();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"не удалось получить список процессов: {ex.Message}");
                return;
            }

            processCount = all.Length;

            string[] names = new string[all.Length];
            int[] pids = new int[all.Length];
            long[] mem = new long[all.Length];
            int valid = 0, exited = 0, denied = 0;

            for (int i = 0; i < all.Length; i++)
            {
                Process p = all[i];
                try
                {
                    int id = p.Id;
                    string name = p.ProcessName;
                    long ws = p.WorkingSet64;

                    names[valid] = name;
                    pids[valid] = id;
                    mem[valid] = ws;
                    valid++;
                }
                catch (InvalidOperationException) { exited++; }
                catch (Win32Exception) { denied++; }
                catch (NotSupportedException) { denied++; }
                finally { p.Dispose(); }
            }

            int topCount = Math.Min(5, valid);
            topNames = new string[topCount];
            topPids = new int[topCount];
            topMemory = new long[topCount];
            bool[] used = new bool[valid];

            for (int k = 0; k < topCount; k++)
            {
                int best = -1;
                for (int i = 0; i < valid; i++)
                {
                    if (!used[i] && (best == -1 || mem[i] > mem[best]))
                    {
                        best = i;
                    }
                }

                used[best] = true;
                topNames[k] = names[best];
                topPids[k] = pids[best];
                topMemory[k] = mem[best];
            }

            Console.WriteLine($"всего процессов в системе: {processCount}");
            if (exited > 0 || denied > 0)
                Console.WriteLine($"пропущено (завершились: {exited}, нет доступа: {denied})");

            Console.WriteLine("\nтоп-5 процессов по потреблению оперативной памяти:");
            for (int i = 0; i < topCount; i++)
            {
                double mb = topMemory[i] / (1024.0 * 1024.0);
                Console.WriteLine($"{i + 1}. {topNames[i]} (pid: {topPids[i]}) — {mb:F2} мб");
            }
        }

        static (int ExitCode, string Output) RunCommand(string fileName, string args)
        {
            try
            {
                using Process p = new Process();
                p.StartInfo.FileName = fileName;
                p.StartInfo.Arguments = args;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;

                if (OperatingSystem.IsWindows())
                {
                    try { p.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(866); }
                    catch { }
                }

                p.Start();
                string output = p.StandardOutput.ReadToEnd();
                string error = p.StandardError.ReadToEnd();
                p.WaitForExit();

                string combined = string.IsNullOrWhiteSpace(output) ? error : output;
                return (p.ExitCode, combined.Trim());
            }
            catch (Exception ex)
            {
                return (-1, ex.Message);
            }
        }

        static async Task CheckNetworkAsync()
        {
            if (!IsFlagSet(FlagNetwork)) { PrintDisabled(2); return; }

            PrintHeader("проверка сети");
            Console.WriteLine("выполняется одновременная проверка 127.0.0.1 и 8.8.8.8...");

            string[] hosts = { "127.0.0.1", "8.8.8.8" };
            Task<(string Host, int ExitCode)>[] tasks = new Task<(string, int)>[hosts.Length];

            for (int i = 0; i < hosts.Length; i++)
            {
                tasks[i] = PingHostAsync(hosts[i]);
            }

            var results = await Task.WhenAll(tasks);
            pingResults = new string[results.Length];

            for (int i = 0; i < results.Length; i++)
            {
                string status = results[i].ExitCode == 0 ? "доступен" : "недоступен";
                pingResults[i] = $"{results[i].Host}: {status} (код завершения: {results[i].ExitCode})";
                Console.WriteLine(pingResults[i]);
            }
        }

        static async Task<(string Host, int ExitCode)> PingHostAsync(string host)
        {
            try
            {
                using Process p = new Process();
                p.StartInfo.FileName = "ping";
                p.StartInfo.Arguments = OperatingSystem.IsWindows() ? $"-n 2 {host}" : $"-c 2 {host}";
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;

                p.Start();
                await p.WaitForExitAsync();
                return (host, p.ExitCode);
            }
            catch
            {
                return (host, -1);
            }
        }

        static void AnalyzeArrayInThreads()
        {
            PrintHeader("анализ массива в двух потоках");

            const int size = 1_000_000;
            int[] arr = new int[size];
            Random rnd = new Random();
            for (int i = 0; i < size; i++)
                arr[i] = rnd.Next(1, 10000);

            int mid = size / 2;
            int part1 = 0;
            int part2 = 0;

            Thread t1 = new Thread(() =>
            {
                int c = 0;
                for (int i = 0; i < mid; i++)
                    if (arr[i] % 2 == 0) c++;
                part1 = c;
            });

            Thread t2 = new Thread(() =>
            {
                int c = 0;
                for (int i = mid; i < size; i++)
                    if (arr[i] % 2 == 0) c++;
                part2 = c;
            });

            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();

            int threadsTotal = part1 + part2;
            evenCount = ArrayHelper.CountEven(arr);
            double avg = ArrayHelper.CalculateAverage(arr);

            arrayResult = $"поток 1: {part1}, поток 2: {part2}, сумма потоков: {threadsTotal}, dll counteven: {evenCount}, среднее: {avg:F2}";

            Console.WriteLine($"поток 1 (первая половина): {part1}");
            Console.WriteLine($"поток 2 (вторая половина): {part2}");
            Console.WriteLine($"общий результат потоков: {threadsTotal}");
            Console.WriteLine($"проверка через dll (counteven): {evenCount}");
            Console.WriteLine($"среднее арифметическое (dll): {avg:F2}");
            Console.WriteLine($"результаты совпадают: {(threadsTotal == evenCount ? "да" : "нет")}");
        }

        static void CheckMemory()
        {
            PrintHeader("проверка памяти");

            long memBefore = GC.GetTotalMemory(true);
            Console.WriteLine($"управляемая память до создания массивов: {memBefore:N0} байт ({memBefore / (1024.0 * 1024.0):F2} мб)");

            const int size = 1_000_000;
            int[] original = new int[size];
            for (int i = 0; i < size; i++)
                original[i] = i + 1;

            int[] secondVar = original;
            int[] copy = new int[size];
            Array.Copy(original, copy, size);

            secondVar[0] = 99999;

            long arrayBytes = (long)size * sizeof(int);
            double arrayMb = arrayBytes / (1024.0 * 1024.0);
            long memAfter = GC.GetTotalMemory(false);

            Console.WriteLine($"первый элемент исходного массива (после изменения через вторую переменную): {original[0]}");
            Console.WriteLine($"первый элемент независимой копии: {copy[0]}");
            Console.WriteLine($"примерный размер массива (1 000 000 int): {arrayBytes:N0} байт ({arrayMb:F2} мб)");
            Console.WriteLine($"управляемая память после создания массивов: {memAfter:N0} байт ({memAfter / (1024.0 * 1024.0):F2} мб)");

            memoryResult = $"исходный={original[0]}, копия={copy[0]}, размер массива={arrayMb:F2} мб, память до={memBefore / (1024.0 * 1024.0):F2} мб, после={memAfter / (1024.0 * 1024.0):F2} мб";

            GC.KeepAlive(original);
            GC.KeepAlive(copy);
        }

        static void ConfigureSettings()
        {
            while (true)
            {
                PrintHeader("настройки диагностики");
                for (int i = 0; i < FlagNames.Length; i++)
                {
                    bool enabled = IsFlagSet(1 << i);
                    Console.WriteLine($"{i + 1}. [бит {i}] {FlagNames[i]}: {(enabled ? "вкл" : "выкл")}");
                }
                Console.WriteLine("0. вернуться в главное меню");
                Console.Write("\nвыберите параметр (1-4) для переключения: ");

                string input = Console.ReadLine();
                if (input == null || input.Trim() == "0") break;

                if (int.TryParse(input.Trim(), out int num) && num >= 1 && num <= 4)
                {
                    flags ^= (1 << (num - 1));
                    SaveSettings();
                    Console.WriteLine($"настройка обновлена. текущее значение flags: {flags} (0b{Convert.ToString(flags, 2).PadLeft(4, '0')})");
                }
                else
                {
                    Console.WriteLine("некорректный ввод.");
                }
            }
        }

        static async Task RunFullDiagnosticsAsync()
        {
            PrintHeader("полная диагностика");

            if (IsFlagSet(FlagCommands)) ShowComputerInfo();
            else PrintDisabled(1);

            if (IsFlagSet(FlagProcesses)) AnalyzeProcesses();
            else PrintDisabled(0);

            if (IsFlagSet(FlagNetwork)) await CheckNetworkAsync();
            else PrintDisabled(2);

            AnalyzeArrayInThreads();
            CheckMemory();

            if (IsFlagSet(FlagReport)) SaveReport();
            else PrintDisabled(3);
        }

        static void SaveReport()
        {
            if (!IsFlagSet(FlagReport)) { PrintDisabled(3); return; }

            PrintHeader("сохранение отчёта");
            Console.Write("укажите путь к папке для сохранения отчёта: ");
            string folder = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(folder))
            {
                Console.WriteLine("путь не указан, сохранение отменено.");
                return;
            }

            folder = folder.Trim();
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
                Console.WriteLine($"создана папка: {folder}");
            }

            DateTime now = DateTime.Now;
            string fileName = $"Report_{now:yyyy-MM-dd_HH-mm-ss}.txt";
            string fullPath = Path.Combine(folder, fileName);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("========== отчёт system inspector ==========");
            sb.AppendLine($"дата и время: {now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"запуск программы №: {launchCount}");
            sb.AppendLine($"имя компьютера: {computerName ?? NotDone}");
            sb.AppendLine($"пользователь: {userName ?? NotDone}");
            sb.AppendLine($"количество процессов: {(processCount >= 0 ? processCount.ToString() : NotDone)}");

            sb.AppendLine("\nтоп-5 процессов по памяти:");
            if (topNames.Length > 0)
            {
                for (int i = 0; i < topNames.Length; i++)
                {
                    double mb = topMemory[i] / (1024.0 * 1024.0);
                    sb.AppendLine($"  {i + 1}. {topNames[i]} (pid: {topPids[i]}) — {mb:F2} мб");
                }
            }
            else
            {
                sb.AppendLine($"  {NotDone}");
            }

            sb.AppendLine("\nрезультаты проверки сети:");
            if (pingResults != null)
            {
                for (int i = 0; i < pingResults.Length; i++)
                    sb.AppendLine($"  {pingResults[i]}");
            }
            else
            {
                sb.AppendLine($"  {NotDone}");
            }

            sb.AppendLine($"\nчётные числа в массиве: {(evenCount >= 0 ? evenCount.ToString() : NotDone)}");
            if (arrayResult != null) sb.AppendLine($"детали анализа массива: {arrayResult}");

            sb.AppendLine($"\nрезультаты проверки памяти: {memoryResult ?? NotDone}");

            sb.AppendLine($"\nтекущие настройки диагностики: flags = {flags} (0b{Convert.ToString(flags, 2).PadLeft(4, '0')})");
            for (int i = 0; i < FlagNames.Length; i++)
            {
                sb.AppendLine($"  бит {i} ({FlagNames[i]}): {(IsFlagSet(1 << i) ? "вкл" : "выкл")}");
            }

            File.WriteAllText(fullPath, sb.ToString(), Encoding.UTF8);
            Console.WriteLine($"отчёт успешно сохранён: {Path.GetFullPath(fullPath)}");
        }

        static void LoadSettings()
        {
            if (OperatingSystem.IsWindows())
            {
                LoadSettingsWindows();
            }
            else if (File.Exists(SettingsFile))
            {
                try
                {
                    string[] lines = File.ReadAllLines(SettingsFile);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        string[] kv = lines[i].Split('=');
                        if (kv.Length == 2)
                        {
                            if (kv[0] == "flags" && int.TryParse(kv[1], out int f)) flags = f;
                            if (kv[0] == "LaunchCount" && int.TryParse(kv[1], out int c)) launchCount = c;
                        }
                    }
                }
                catch { }
            }
        }

        [SupportedOSPlatform("windows")]
        static void LoadSettingsWindows()
        {
            try
            {
                using RegistryKey key = Registry.CurrentUser.OpenSubKey(RegistryPath);
                if (key != null)
                {
                    if (key.GetValue("flags") is int f) flags = f;
                    if (key.GetValue("LaunchCount") is int c) launchCount = c;
                }
            }
            catch { }
        }

        static void SaveSettings()
        {
            if (OperatingSystem.IsWindows())
            {
                SaveSettingsWindows();
            }
            else
            {
                try
                {
                    File.WriteAllLines(SettingsFile, new[] { $"flags={flags}", $"LaunchCount={launchCount}" });
                }
                catch { }
            }
        }

        [SupportedOSPlatform("windows")]
        static void SaveSettingsWindows()
        {
            try
            {
                using RegistryKey key = Registry.CurrentUser.CreateSubKey(RegistryPath);
                key.SetValue("flags", flags, RegistryValueKind.DWord);
                key.SetValue("LaunchCount", launchCount, RegistryValueKind.DWord);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ошибка записи в реестр: {ex.Message}");
            }
        }
    }
}
