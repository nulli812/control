﻿namespace SystemLibrary
{
    public static class ArrayHelper
    {
        public static double CalculateAverage(int[] a)
        {
            if (a == null || a.Length == 0)
                return 0.0;

            long sum = 0;
            for (int i = 0; i < a.Length; i++)
            {
                sum += a[i];
            }

            return (double)sum / a.Length;
        }

        public static int CountEven(int[] a)
        {
            if (a == null || a.Length == 0)
                return 0;

            int count = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 == 0)
                    count++;
            }

            return count;
        }
    }
}
